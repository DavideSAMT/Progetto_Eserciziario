<?php 
/**
* 
*/
class Logout
{
	public function index()
	{
		session_destroy();
		header("location: http://eserciz.samtinfo.ch/login/index/");
	}
}