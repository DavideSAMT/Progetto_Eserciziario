<?php
/**
* 
*/
class Login
{
	public $count = 0;
	/*
		Funzione che carica la pagina di index
		e fa la connesione al server
	*/
	public function index($msn = "")
	{
		require_once 'application/models/connection.php';
		$connection = new Connection("efof.myd.infomaniak.com","efof_eserciz2018","Eserciz_Admin2018", "efof_Eserciz2018");
		$connection->sqlConnection();
		require 'application/views/_templates/header.php';
		require 'application/views/login/index.php'; 
	}

	/*
		Funzione che richiama la classe Connection e inserisce i dati nel Database
	*/
	public function registra()
	{
		$this->count = 0;
		require_once 'application/models/connection.php';
		$connection = new Connection("efof.myd.infomaniak.com","efof_eserciz2018","Eserciz_Admin2018", "efof_Eserciz2018");
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nome = $_POST["nome"];
            $cognome = $_POST["cognome"];
            $mail = $_POST["mail"];
            $pass = $_POST["pass"];
            $pass = md5($pass);
            $materie = array();
            for ($i=4; $i < count($_POST); $i++) { 
            	if (isset($_POST["materia".$this->count])) {
            		array_push($materie, $_POST["materia".$this->count]);
            	}
            	$this->count++;
            }
        }

        if ((strcmp($nome, "") || strcmp($cognome, "") || strcmp($mail, "") || strcmp($pass, ""))) {
        	$msn = ($connection->insertRecord($nome, $cognome, $mail, $pass));
        	$msn = ($connection->insertMatDoc($mail, $materie));
        }
		header("location: http://eserciz.samtinfo.ch/login/index/");
	}
	/*
		Funzione che richiama il metodo della classe Connection che controlla se le credenziali sono corrette
	*/
	public function log_in()
	{
		require_once 'application/models/connection.php';
		$connection = new Connection("efof.myd.infomaniak.com","efof_eserciz2018","Eserciz_Admin2018", "efof_Eserciz2018");
		if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $mail = $_POST["mail"];
            $pass = $_POST["pass"];
            $pass = md5($pass);
            //echo $pass;
        }
        if ((strcmp($mail, "") || strcmp($pass, ""))) {
        	$var = ($connection->getUser($mail, $pass));
        	switch ($var) {
        		case 1: // LOGIN
        			$_SESSION['mail'] = $mail;
        			header("location: http://eserciz.samtinfo.ch/home/index/".$_SESSION['mail']);
        			break;
        		
        		case 2: // PASSWORD SBAGLIATA
 					$this->phpAlert("Password Errata");
        			$this->index();
        			break;

        		default: // UTENTE NON REGISTRATO
        			$this->phpAlert("Utente non registrato");
        			$this->index();
        			break;
        	}
        } 
        
	}

	function phpAlert($msg) {
    	echo '<script type="text/javascript">alert("' . $msg . '")</script>';
	}
} 