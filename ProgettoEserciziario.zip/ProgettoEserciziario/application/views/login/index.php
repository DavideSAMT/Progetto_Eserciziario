
    <title>Login</title>
</head>
<body>
    <header>
        <h1>Login Eserciziario</h1>
        
    </header>
    <br>
<div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="panel panel-login">
                    <div class="panel-heading">
                        <div class="row">
                            <div class="col-xs-6">
                                <a href="#" class="active" id="login-form-link">Login</a>
                            </div>
                            <div class="col-xs-6">
                                <a href="#" id="register-form-link">Registrati</a>
                            </div>
                        </div>
                        <hr>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-12">
                                <form id="login-form" action="http://eserciz.samtinfo.ch/login/log_in" method="post" role="form" style="display: block;">
                                    <div class="form-group">
                                        <input type="text" name="mail" id="username" tabindex="1" class="form-control" placeholder="Indirizzo Mail" pattern="\S+@\S+\.\S+\" onkeyup="convalida(this.value, this.id, regMail)" value="">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="pass" id="password" tabindex="2" class="form-control" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" value="Login">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="text-center">
                                                    <a href="http://eserciz.samtinfo.ch/passwordRecovery" tabindex="5" class="forgot-password">Password dimenticata?</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                                <form id="register-form" action="http://eserciz.samtinfo.ch/login/registra" method="post" role="form" style="display: none;">
                                    <div class="form-group">
                                        <input type="text" name="nome" id="nome" tabindex="1" class="form-control" placeholder="Nome" value="" required="true" onkeyup="convalida(this.value, this.id, regLetters)">
                                    </div>
                                     <div class="form-group">
                                        <input type="text" name="cognome" id="cognome" tabindex="1" class="form-control" placeholder="Cognome" value="" required="true"
                                        onkeyup="convalida(this.value, this.id, regLetters)">
                                    </div>
                                    <div class="form-group">
                                        <input type="email" name="mail" id="mail" tabindex="1" class="form-control" placeholder="Indirizzo Mail" value="" required="true" pattern="\S+@\S+\.\S+\" onkeyup="convalida(this.value, this.id, regMail)">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="pass" id="pass" tabindex="2" class="form-control" placeholder="Password" onkeyup="controllaPassword(this.value)">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password" onkeyup="confirm()" disabled="true">
                                    </div>
                                    <div class="form-group" id="sceltaMultipla">
                                        <?php $mat =  $connection->getMaterie(); ?>
                                        <?php $id =  $connection->getMaterie(true); ?>
                                        <select name="materia0" required="true" id="selMaterie0">
                                            <option value="" selected="true" disabled="true" hidden="true"> Scegli materia...</option>
                                            <?php for ($i=0; $i < count($mat); $i++): ?>
                                                <?php echo"<option value=$id[$i]>" ?>
                                                    <?php echo " ".$mat[$i] ?>
                                                <?php echo"</option>" ?>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <button type="button" class="btn btn-default" onclick="aggiungiScelta()"> + </button>
                                         <button type="button" id="remove" class="btn btn-default" onclick="rimuoviScelta()" disabled=""> x </button>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6 col-sm-offset-3">
                                                <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Registra" disabled="true">
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>
</html>