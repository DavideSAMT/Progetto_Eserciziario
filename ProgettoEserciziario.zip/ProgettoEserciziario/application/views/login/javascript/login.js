$(function() {

            $('#login-form-link').click(function(e) {
                $("#login-form").delay(100).fadeIn(100);
                $("#register-form").fadeOut(100);
                $('#register-form-link').removeClass('active');
                $(this).addClass('active');
                e.preventDefault();
            });
            $('#register-form-link').click(function(e) {
                $("#register-form").delay(100).fadeIn(100);
                $("#login-form").fadeOut(100);
                $('#login-form-link').removeClass('active');
                $(this).addClass('active');
                e.preventDefault();
            });

        });
        var regMail = /\S+@\S+\.\S+/;
        var regLetters = /^[a-z ]+$/i;
        function convalida(value, inp, regexp) {
            if (!regexp.test(value) || value == "") {
                document.getElementById(inp).style = "color: red";
                document.getElementById("register-submit").disabled = true;
                //console.log("enter");
            } else {
                document.getElementById(inp).style = "color: black;";
            }
        }
        function confirm() {
            var confirm_password = document.getElementById('confirm-password').value;
            var pass = document.getElementById('pass').value;
            if ((pass == confirm_password) && (pass != "")){
                document.getElementById('register-submit').disabled = false;

            } else {
                document.getElementById('register-submit').disabled = true;
            }
        }
        function controllaPassword(str) {
            var confirm_password = document.getElementById('confirm-password').value;
            if (!(str == "")) {
                document.getElementById('confirm-password').disabled = false;
            } else {
                document.getElementById('confirm-password').disabled = true;
            }
            if (str == confirm_password && !(str == "")) {
                document.getElementById('register-submit').disabled = false;
            } else {
                document.getElementById('register-submit').disabled = true;
            }
        }
        var index = 1;
        function aggiungiScelta() {
            var element = document.getElementById("sceltaMultipla");
            var sel = document.getElementById('selMaterie0');
            var cln = sel.cloneNode(true);
            cln.name = "materia"+index;
            cln.id = "selMaterie"+index;
            index++;
            element.appendChild(cln);
            if (index > 0) {
                var remove = document.getElementById('remove');
                remove.disabled = false;
            }
        }

        function rimuoviScelta() {
            index--;
            var element = document.getElementById("sceltaMultipla");
            var sel = document.getElementById("selMaterie"+index);
            element.removeChild(sel);
            if (index <= 1) {
                var remove = document.getElementById('remove');
                remove.disabled = true;
            }
        }