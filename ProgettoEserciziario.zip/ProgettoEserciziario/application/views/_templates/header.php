<!DOCTYPE html>
<html>
<head><!--
	<link rel="stylesheet" type="text/css" href="application/views/_templates/bootstrap.min.css">
	<script type="text/javascript" src="application/views/_templates/bootstrap.min.js"></script>-->
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php  echo URL; ?>application/views/login/javascript/login.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php  echo URL; ?>application/views/login/css/login.css">