
				<!--Parte principale del sito-->
				<section id="content" class="column-right">
					<article>
						<h2>Seleziona Serie</h2>

						<br>
						<form method="post" action="http://eserciz.samtinfo.ch/application/views/CreazioneDomanda/creaDomanda.php" id="formD">
							<!-- Select per la selezione della difficoltà -->
							<select required>
								<option value="" selected disabled hidden id="serie">Seleziona serie</option>
								
								<?php  ?>

							</select>
						</form>
						<input type="button" name="submitSalvaS" value="Salva" style="margin-left: 20%">
						<br>
						<input type="button" name="submitStampaS" value="Stampa" style="margin-left: 20%">
						<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>