<?php
session_destroy();
require 'http://localhost/progetto-MVC/home/disconetti/<?php echo $mail ?>';
?>