
					</article>
					<footer class="clear">
						<p>&copy; 2018 Eserciziario. By <a href="http://samtinfo.ch/i15pardav/web/">Davide Paradiso</a> and <a href="http://samtinfo.ch/i15maugia/web/">GiairoMauro</a></p>
					</footer>
				</section>
		
				<div class="clear"></div>
			</section>
		</body>
	</html>	