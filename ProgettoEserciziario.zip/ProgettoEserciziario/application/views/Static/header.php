<!doctype html>
	<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
			<title>Eserciziario</title>
			<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0" />
			<link rel="stylesheet" type="text/css" href="http://eserciz.samtinfo.ch/application/views/Static/css/styles.css">
		</head>
		
		<body>
			<!--Sezione generale-->
			<section id="body" class="width">